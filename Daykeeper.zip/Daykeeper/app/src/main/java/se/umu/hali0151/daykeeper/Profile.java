package se.umu.hali0151.daykeeper;

/**
 * @author id18hll
 * @version 1.0
 * Profile class for saved settings etc. NOT USED RIGHT NOW.
 */

public class Profile {
}
